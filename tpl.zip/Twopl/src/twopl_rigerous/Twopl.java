package twopl_rigerous;

//// Name : AMEY JAYANT  PURANIK


import java.io.*;   //// importing the input and output package of java for reading and the file 
import java.util.*; //// importing the util package for the data structures

public class Twopl {  //// Declaring the global class.
	//// declaring hashtable to save transaction functions.
	public static HashMap<Integer, Transaction_table> transaction_table = new HashMap<Integer, Transaction_table>();
	////Declaring hashtable to lock table.
	public static HashMap<String, Assign_lock> lock_up_table = new HashMap<String, Assign_lock>();

	public int Write_lock;
	public int Read_lock;
   
	public void readclasstrigger() { //// method to trigger the fileread_fromtext .

		Twopl txt_file = new Twopl();  ////creating the object. 
		txt_file.Fileread_fromtext();  //// call the method using the declared object.

	}
	//// initiliazing  queue to store the blocked transactions.
	public static Queue<Integer> waiting_queue = new PriorityQueue<Integer>();
	//// Declaring an  public global array to store the transaction schedule.
	public static String[] filedata = new String[100];

	public int wait_Read;
	public int Write_wait;
	////main class.
	public static void main(String args[]) {
		//// print statement
		System.out.println(
				"The program is running  successfully. Now, please enter the input file name in (filename.txt, example : inputread.txt) format. ");

		new Twopl().readclasstrigger(); //// calling the readclasstrigger to avoid static variables problem.
		new Twopl().trigger();       //// calling the trigger to avoid static variables problem.

	}

	public void trigger() {   ////Method to invoke the ReadTransactions method.

		Transaction_table obj4 = new Transaction_table(); //// creating the object to invoke the default method.
		obj4.ReadTransactions();

	}

	public void Fileread_fromtext() {  //// method to read the file from the text file.
		//// initializing the string with the location of the file.
		String filelocation = "E:/root/";
		FileInputStream is; //// initializing the file input stream reader to open the file 
		BufferedReader br;  //// initializing the buffer reader to read the file.

		String[] read_file; ////String array to store the data from the file.
		read_file = new String[125];

		Scanner input = new Scanner(System.in); //// to take file name from the command line.
		String filename = input.nextLine(); //// to read the file name from the commad line.
		// The location of the input file is hard coded.
		////try-catch block to handle exception.
		try {
			is = new FileInputStream(filelocation + filename);
			br = new BufferedReader(new InputStreamReader(is));
			int i = 0;
			String l = br.readLine();   

			while (l != null) {  //// while loop to traverse through the string.
				read_file[i] = l;
				l = br.readLine(); //// reading  line by line.
				////System.out.println(read_file[i]);
				i++;

			}
			br.close(); //// closing the buffer reader.

		} catch (Exception e) { //// catch block to handle exceptions.
			System.out.println(
					"Something went wrong!! Please check the file location. (Transaction Schedule File (input file) should be saved in E:/root)");
		}

		input.close(); //// closing the input stream reader.
		filedata = read_file; //// assigning the array to global array.
	}

	public class Assign_lock {   //// lock table global class.
		//// initializing the write lock.
		public int Write_lock; 
		////initializing the Read lock.
		public int Read_lock; 
		////initializing the wait  lock.
		public int wait_Read;
		//// initializing the wait lock
		public int Write_wait;
	 //// Default method.
		public Assign_lock() {
			int x = 0;
		//// initializing the write lock as unlocked.
			this.Write_lock = x;
		//// initializing the read lock as unlocked.
			this.Read_lock = x;
		//// initializing the wait lock as unlocked.
			this.wait_Read = x;
		//// initializing the wait lock as unlocked.
			this.Write_wait = x;

		}

		public void lock_r() {//// method for lock items.
			String y = "";
			System.out.println("The transaction has a read lock on item" + y);

		}

		public int unlock_G_read() { //method to  get read lock on the transactions 
			int lock;
			lock = this.Read_lock;  
			return lock; //// returning the lock type
		}

		public void Read_lock(int x) { // method to get and set read lock on the transaction items 

			String y;
			y = Integer.toString(x);
			this.Read_lock = Integer.parseInt(y);  //// setting the lock as transaction id.

		}

		public void Read_lock_remove() { //  Method to remove read lock from the transaction schedules.
			int x = 0;
			this.Read_lock = x; //// Setting this a lock key value
		}

		public int Unlock_G_write() { //  method to get write lock on the transaction vairable.
			int lock;
			lock = this.Write_lock;
			return lock; //// returning this value when called.
		}

		public void lock_w() { //  method to set  write lock on the transaction vairable.
			String y = "";
			System.out.println("The transaction has a write lock on item" + y);

		}

		public void Write_lock(int x) { //  method to set and get  write lock on the transaction vairable.

			this.Write_lock = x;  //// Setting this a lock key value
		}

		public void Remove_writelock() { //  method to remove  write lock on the transaction vairable.
			int x = 0;// remove writelock
			this.Write_lock = x;   //// Setting this a lock key value
		}

		public int unlocK_g_waitread() { //  method to get wating  write lock on the transaction vairable.
			int lock;
			lock = this.wait_Read;
			return lock; //// returning this value when called.
		}

		public void Waait_read(int x) { //  method to set waiting  write lock on the transaction vairable.

			String l;
			l = Integer.toString(x);
			int i = Integer.parseInt(l);
			this.wait_Read = i;  //// Setting this a lock key value

		}

		public void remove_waitread() { //  method to remove waiting  write lock on the transaction vairable.
			int x = 0;/// remove waiting read
			this.wait_Read = x;  //// Setting this a lock key value 
		}

		public int unlock_g_waiting_read() { //  method to get waiting  read  lock on the transaction vairable.
			int lock;
			lock = this.Write_wait;
			return lock; //// returning this value when called.
		}

		public void w_writelock(int x) {//  method to set  waiting read lock on the transaction vairable.

			String l;
			int i;
			l = Integer.toString(x);
			i = Integer.parseInt(l);
			this.Write_wait = i;   //// Setting this a lock key value

		}

		public void remove_w_WriteLock() {  //  method to get write lock on the transaction vairable.
			int x = 0;// remve waiting write
			this.Write_wait = x; //// Setting this a lock key value
		}

	}

	public class Transaction_table {  ////global class for transaction table.

		public String to_clr_lockup = ""; //// declaring the string to store and then later clear the lockuptable.
		public int Transaction_ts;  //// transaction time stamp 

		int timestamp = 0;  
		public String state; //// Declaring the string value to store in the transaction table.

		public String lockedkeys;  //// Declaring the string value to store in the transaction table.
		public String ps;
		public String[] transaction_sch = new String[200]; //// Declaring the string array  value to store in the transaction schedule .

		public Transaction_table() {
		}
	//// a constructor to store the values in the transaction table when called as a object.   
		public Transaction_table(String state, String lockedkeys) {
			this.Transaction_ts = ++timestamp;
			// TS++;
			this.state = state;
			this.lockedkeys = lockedkeys;  
		}

		public void ReadTransactions() {  //// a method to traverse through the transaction table saved on the array declared in the method. (core part)

			for (int i = 0; i < Twopl.filedata.length; i++) {  ////for loop to traverse through the string array.

				transaction_sch[i] = Twopl.filedata[i];

			}
			int i = 0;
			while (transaction_sch[i] != null) {  //// while loop to check that the string is not empty and if that is true then it will execute te following.

				if (transaction_sch[i].substring(0, 1).equals("b")) {  ////if loop if the string value starts with b
					
					Transaction_table data_in_hm = new Transaction_table("Active", "none"); //// putting this in transaction table.
					int id_tran = Integer.parseInt(transaction_sch[i].substring(1, transaction_sch[i].indexOf(";"))); //// extracting the transactionn value from the string.
					Twopl.transaction_table.put(id_tran, data_in_hm); //// putting this in transaction table
					System.out.println("Process begin for Transaction: T" + id_tran + "\n");

				}
				if (transaction_sch[i].substring(0, 1).equals("r")) {  ////if loop if the string value starts with r.
				//// extracting the transactionn value from the string.
					int id_tran = Integer.parseInt(transaction_sch[i].substring(1, transaction_sch[i].indexOf(" ")));
                    ////calling the lock table class by declaring the objects.
					Assign_lock L = new Assign_lock();
					L.Read_lock(id_tran);
				//// extracting the item  value from the string.
					String item = transaction_sch[i].substring(transaction_sch[i].indexOf("(") + 1,
							transaction_sch[i].indexOf(")"));

					if (id_tran == 1) { //// saving the list of items locked by transaction 
						to_clr_lockup = to_clr_lockup + item;

					}
					if (id_tran == 2) { //// saving the list of items locked by transaction 
						to_clr_lockup = to_clr_lockup + item;

					}
					if (id_tran == 3) { //// saving the list of items locked by transaction 
						to_clr_lockup = to_clr_lockup + item;

					}
					if (id_tran == 4) {//// saving the list of items locked by transaction 
						to_clr_lockup = to_clr_lockup + item;

					}
					if (id_tran == 5) { //// saving the list of items locked by transaction 
						to_clr_lockup = to_clr_lockup + item;

					}

				//// checking the item is already there in the lock table. 
					if (!Twopl.lock_up_table.containsKey(item)) {
					//// inserting values in the locktable.
						Twopl.lock_up_table.put(item, L); 
					//// print statement.
						System.out.println("Perform Read. " + "\n" + "Transaction:" + id_tran
								+ " issued read lock on item " + item + "\n" + "Read_item (" + item + ")" + '\n');
						Twopl.transaction_table.get(id_tran).mak_itemlock(item);
					//// if the value is already present in the table then abort transaction 
					} else {
						for (String if_locked : Twopl.lock_up_table.keySet()) {
						//// if loop to ckeck in the lock-up table 
							if (if_locked.equals(item)) {
								//// if loop to check the lock type 
								if ((Twopl.lock_up_table.get(item).Unlock_G_write()) != 0) {
									//// print statement.
									System.out.println("Item requested " + if_locked
											+ " has a  Write lock  and may not  be available to read" + '\n');
									//// item and transaction adding the the queue to wait.
									addinqueue(id_tran);
									//// setting the values in the transaction table as aborted.
									Twopl.transaction_table.get(id_tran).set_t_state("Aborted");
									
									Twopl.lock_up_table.get(item).w_writelock(id_tran);
								}
								if ((Twopl.lock_up_table.get(item).unlock_G_read()) != 0) {

									Twopl.lock_up_table.get(item).Read_lock(id_tran);
									//// print statement.
									System.out.println("Perform Read. " + "\n" + "Transaction:" + id_tran
											+ " issued read lock on item " + item + "\n" + "Read_item (" + item + ")"
											+ '\n');

									Twopl.transaction_table.get(id_tran).mak_itemlock(item);
								}
							}}}}
				
				
				//// If the sarting of the string array is w then it enters this if loop 
				if (transaction_sch[i].substring(0, 1).equals("w")) {
				//// extracting the item  value from the string.
					String item_n = transaction_sch[i].substring(transaction_sch[i].indexOf("(") + 1,
							transaction_sch[i].indexOf(")"));
				//// extracting the transactionn value from the string.
					int tid = Integer.parseInt(transaction_sch[i].substring(1, transaction_sch[i].indexOf(" ")));

					if (tid == 1) { //// saving the list of items locked by transaction
						to_clr_lockup = to_clr_lockup + item_n;

					}
					if (tid == 2) {//// saving the list of items locked by transaction
						to_clr_lockup = to_clr_lockup + item_n;

					}
					if (tid == 3) {//// saving the list of items locked by transaction
						to_clr_lockup = to_clr_lockup + item_n;

					}
					if (tid == 4) { //// saving the list of items locked by transaction
						to_clr_lockup = to_clr_lockup + item_n;

					}
					if (tid == 5) { //// saving the list of items locked by transaction
						to_clr_lockup = to_clr_lockup + item_n;

					}

					Assign_lock lock = new Assign_lock();
					lock.Write_lock(tid); ////  calling the locktable class again using the object.

					if (!Twopl.lock_up_table.containsKey(item_n)) {
						//// putting values in the lock up table.
						Twopl.lock_up_table.put(item_n, lock);
						//// print statement.
						System.out.println(
								"Perform write. " + "\n" + "Transaction:" + tid + " has issued  a write lock on item "
										+ item_n + "\n" + "Write_item (" + item_n + ")" + '\n');
					} else {
 
						for (String key : Twopl.lock_up_table.keySet()) {
							//// checking in the lock up table.
							if (key.equals(item_n)) {
								//// if loop if there is  not write lock on the item saved in the lock table.
								if ((Twopl.lock_up_table.get(item_n).Unlock_G_write()) != 0) {
									//// comparing the timestamp.
									int req_ts_teans = Twopl.transaction_table.get(tid).timestamp();
									int hold_ts_trans = Twopl.lock_up_table.get(item_n).Unlock_G_write();

									if (req_ts_teans < hold_ts_trans) {
										//// adding the transaction in the queue.
										addinqueue(tid);
										//// setting the transaction state as blocked.
										Twopl.transaction_table.get(tid).set_t_state("Blocked");
										Twopl.lock_up_table.get(item_n).w_writelock(tid);
										
					
									}
								} else {
									//// if loop to check  the read lock is on the item. 
									if ((Twopl.lock_up_table.get(item_n).unlock_G_read()) != 0)
									//// check if read lock already present on the item.
									{
										int len_transid_RL = (int) (Math
												.log10(Twopl.lock_up_table.get(item_n).unlock_G_read()) + 1);
										if (len_transid_RL < 2
												&& Twopl.lock_up_table.get(item_n).unlock_G_read() == tid)
										{ //// print statement.
											System.out.println("Perform write. " + "\n" + "Transaction:" + tid
													+ " is Upgrading readlock to writelock on item " + item_n + "\n"
													+ "Write_item (" + item_n + ")" + '\n');
											//// removing the read lock 
											Twopl.lock_up_table.get(item_n).Read_lock_remove();
											//// putting the write lock.
											Twopl.lock_up_table.get(item_n).Write_lock(tid);

										}
									}}
							}}}}
				//// if the string starts with the letter e 
				if (transaction_sch[i].substring(0, 1).equals("e")) { 

					String s = null;
                             
					int id = Integer.parseInt(transaction_sch[i].substring(1, transaction_sch[i].indexOf(";")));

					if (id == 1) {  //// if loop to remove items locked by the transaction from the loop-up table.

						for (int j = 0; j < to_clr_lockup.length(); j++) {
							s = to_clr_lockup.substring(j, j + 1);
							Twopl.lock_up_table.remove(s);

						}

					}
					if (id == 2) { //// if loop to remove items locked by the transaction from the loop-up table.

						for (int j = 0; j < to_clr_lockup.length(); j++) {
							s = to_clr_lockup.substring(j, j + 1);
							Twopl.lock_up_table.remove(s);

						}

					}
					if (id == 3) { //// if loop to remove items locked by the transaction from the loop-up table.

						for (int j = 0; j < to_clr_lockup.length(); j++) {
							s = to_clr_lockup.substring(j, j + 1);
							Twopl.lock_up_table.remove(s);

						}

					}
					if (id == 4) { //// if loop to remove items locked by the transaction from the loop-up table.

						for (int j = 0; j < to_clr_lockup.length(); j++) {
							s = to_clr_lockup.substring(j, j + 1);
							Twopl.lock_up_table.remove(s);

						}

					}
					if (id == 5) { //// if loop to remove items locked by the transaction from the loop-up table.

						for (int j = 0; j < to_clr_lockup.length(); j++) {
							s = to_clr_lockup.substring(j, j + 1);
							Twopl.lock_up_table.remove(s);

						}

					}
                 //// Set transaction state as blocked,
					if (Twopl.transaction_table.get(id).g_trans_state().equals("Blocked")) {
						//// print statement.
						System.out.println("Transaction : " + id + " is Blocked" + '\n');

					}
				//// Set transaction state as aborted,
					if (Twopl.transaction_table.get(id).g_trans_state().equals("Aborted")) {
						System.out.println("Transaction :" + id + " is  already Aborted !");
					}
				//// Set transaction state as commited.
					if (Twopl.transaction_table.get(id).g_trans_state().equals("Active")) {

						System.out.println("Transaction : " + id + " is Committed" + '\n');

						set_free(id);  //// releasing all the items from transaction table 

					}
				}

				i++;

			}
		}

		public String coll_keylocked() {  //// Method to return item locked with keys 
			String y;
			y = this.lockedkeys;
			return y; /// returning this value when called.
		}

		public void mak_itemlock(String item) {
			if (this.lockedkeys.equals("none")) {
				this.lockedkeys = item;
			} else
				this.lockedkeys = this.lockedkeys + item;
		}

		public String g_trans_state() { //// method to return state of the transaction.
			String y;
			y = this.state;
			return y; /// returning this value when called.
		}

		public void set_free(int id) {  ////method to releasing all the locked item and changing there status in the transaction table. 

			String locked_keys = Twopl.transaction_table.get(id).coll_keylocked();

			if (locked_keys.equals("none")) {
				System.out.println("All items released");
			} else {

				Twopl.transaction_table.get(id).replacelockedkeys();

				Twopl.transaction_table.get(id).set_t_state("Committed"); //// set it as commited 
				Twopl.transaction_table.get(id).mak_itemlock("none"); //// set it as none.
				//// print statement.
				System.out.println("All items that were held, released by the transaction T" + id + "\n");
				Twopl.waiting_queue.remove(id);

			}
		}

		public int timestamp() { //// method to return the time stamp 
			int x;
			x = this.Transaction_ts;
			return x; /// returning this value when called.
		}

		public void set_t_state(String state) {   //// to return the state 

			this.state = state;
		}

		private void replacelockedkeys() { //// replacing the locked keys 

			String y = "";
			this.lockedkeys = y; 
		}

	}

	public void addinqueue(int id) {  //// to add transactions in the queue 
		Twopl.waiting_queue.add(id);
	}

	public void remove_fromqueue(int id) { //// to remove transactions from the queue.
		Twopl.waiting_queue.remove(id);
	}

}